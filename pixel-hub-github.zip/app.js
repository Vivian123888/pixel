const STORAGE_KEY = "pixelHubDataV1";

const demoData = {
  people: [
    {id:1,name:"Ana Clara Souza",course:"Engenharia de Produção",period:7,email:"ana@cefet-rj.br",status:"Ativa",interest:"Gestão de projetos",projects:[1]},
    {id:2,name:"João Pedro Lima",course:"Engenharia de Computação",period:6,email:"joao@cefet-rj.br",status:"Ativo",interest:"Programação",projects:[1]},
    {id:3,name:"Maria Eduarda Alves",course:"Design",period:5,email:"maria@cefet-rj.br",status:"Ativa",interest:"Game Design / Arte",projects:[2]},
    {id:4,name:"Pedro Henrique Costa",course:"Engenharia de Produção",period:8,email:"pedro@cefet-rj.br",status:"Ativo",interest:"Dados / Gestão",projects:[1,3]},
    {id:5,name:"Larissa Martins",course:"Ciência da Computação",period:4,email:"larissa@cefet-rj.br",status:"Interessada",interest:"Programação / IA",projects:[]},
    {id:6,name:"Gabriel Rocha",course:"Engenharia Mecânica",period:6,email:"gabriel@cefet-rj.br",status:"Interessado",interest:"Modelagem",projects:[]}
  ],
  projects: [
    {id:1,title:"Jogo A — Gestão e Desenvolvimento",type:"Projeto de extensão",status:"Ativo",start:"2026-08-01",end:"2026-12-15",advisor:"Prof. Parreiras",description:"Projeto demonstrativo para organização do ciclo de desenvolvimento de jogos.",goal:"Consolidar um protótipo jogável e validar o processo de gestão.",members:[1,2,4],progress:62},
    {id:2,title:"Jogo B — Experiência e Arte",type:"Iniciação científica",status:"Em desenvolvimento",start:"2026-07-15",end:"2027-02-20",advisor:"Profª. Laryssa",description:"Investigação aplicada a experiência do jogador e linguagem visual.",goal:"Desenvolver e testar uma proposta visual.",members:[3],progress:38},
    {id:3,title:"Blockchain",type:"Projeto final / TCC",status:"Concluído",start:"2025-02-01",end:"2026-06-30",advisor:"Prof. Orientador",description:"Projeto histórico do PIXEL.",goal:"Entrega do trabalho final.",members:[4],progress:100},
    {id:4,title:"Bullwhip",type:"Iniciação científica",status:"Não informado",start:"2025-01-01",end:"2025-12-20",advisor:"Não informado",description:"Registro histórico.",goal:"Documentação.",members:[],progress:0},
    {id:5,title:"Corrida",type:"Projeto de extensão",status:"Não informado",start:"2024-01-01",end:"2024-12-20",advisor:"Não informado",description:"Registro histórico.",goal:"Documentação.",members:[],progress:0},
    {id:6,title:"Decompõe",type:"Projeto de extensão",status:"Não informado",start:"2024-01-01",end:"2024-12-20",advisor:"Não informado",description:"Registro histórico.",goal:"Documentação.",members:[],progress:0},
    {id:7,title:"Divulga PIXEL",type:"Projeto / iniciativa",status:"Ativo",start:"2026-01-01",end:"2026-12-20",advisor:"Coordenação PIXEL",description:"Comunicação e divulgação das atividades do grupo.",goal:"Ampliar a comunicação do grupo.",members:[1,5],progress:70}
  ],
  meetings: [
    {id:1,title:"Reunião geral PIXEL",date:"2026-10-01",start:"17:00",end:"18:00",type:"Reunião PIXEL",projectId:null,location:"Online",notes:"Acompanhamento geral e próximos passos.",present:[1,2,3,4]},
    {id:2,title:"Sprint Review — Jogo A",date:"2026-10-08",start:"17:00",end:"18:00",type:"Reunião de projeto",projectId:1,location:"Laboratório",notes:"Apresentação do protótipo.",present:[1,2]},
    {id:3,title:"Playtest — Jogo B",date:"2026-10-15",start:"17:00",end:"18:30",type:"Playtest",projectId:2,location:"Casa da Inovação",notes:"Teste com usuários.",present:[3]}
  ],
  events: [
    {id:1,title:"Reunião geral PIXEL",date:"2026-10-01",type:"Reunião",color:"purple"},
    {id:2,title:"Sprint Review — Jogo A",date:"2026-10-08",type:"Projeto",color:"blue"},
    {id:3,title:"Playtest — Jogo B",date:"2026-10-15",type:"Evento",color:"green"},
    {id:4,title:"Entrega acadêmica",date:"2026-10-20",type:"Prazo",color:"yellow"}
  ],
  approvals: [
    {id:1,title:"Novo projeto — Jogo C",requester:"Larissa Martins",type:"Projeto de extensão",date:"2026-09-29",status:"Pendente",description:"Solicitação de entrada no portfólio do PIXEL."}
  ],
  hours: [
    {id:1,personId:1,projectId:1,activity:"Gestão e reuniões",date:"2026-09-10",hours:12},
    {id:2,personId:2,projectId:1,activity:"Programação",date:"2026-09-12",hours:18},
    {id:3,personId:3,projectId:2,activity:"Game Design",date:"2026-09-14",hours:10},
    {id:4,personId:4,projectId:1,activity:"Documentação",date:"2026-09-16",hours:14}
  ],
  tasks: [
    {id:1,projectId:1,title:"Corrigir movimentação",personId:2,status:"Em andamento",due:"2026-10-03"},
    {id:2,projectId:1,title:"Atualizar GDD",personId:1,status:"Concluída",due:"2026-09-28"},
    {id:3,projectId:2,title:"Finalizar personagem principal",personId:3,status:"Em andamento",due:"2026-10-10"}
  ]
};

let db = loadData();
let currentView = "dashboard";

function loadData() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : structuredClone(demoData);
  } catch(e) { return structuredClone(demoData); }
}
function saveData() { localStorage.setItem(STORAGE_KEY, JSON.stringify(db)); }
function nextId(arr) { return arr.length ? Math.max(...arr.map(x=>Number(x.id)||0))+1 : 1; }
function esc(s="") {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
function statusClass(status="") {
  const s = status.toLowerCase();
  if (s.includes("ativo") || s.includes("conclu")) return "green";
  if (s.includes("desenvol") || s.includes("pendente")) return "yellow";
  if (s.includes("atras")) return "red";
  if (s.includes("inform")) return "gray";
  return "purple";
}
function badge(status) { return `<span class="badge ${statusClass(status)}">${esc(status)}</span>`; }
function personName(id) { return db.people.find(p=>p.id===Number(id))?.name || "Não informado"; }
function projectName(id) { return db.projects.find(p=>p.id===Number(id))?.title || "Sem projeto"; }
function fmtDate(s) { if(!s) return "—"; const [y,m,d]=s.split("-"); return `${d}/${m}/${y}`; }
function showToast(msg) {
  const t=document.getElementById("toast"); t.textContent=msg; t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),2200);
}

document.getElementById("mainNav").addEventListener("click", e=>{
  const btn=e.target.closest(".nav-item"); if(!btn) return;
  currentView=btn.dataset.view;
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x===btn));
  render();
});
document.getElementById("resetDemo").addEventListener("click",()=>{
  if(confirm("Restaurar os dados de demonstração? As alterações locais serão perdidas.")){
    db=structuredClone(demoData); saveData(); render(); showToast("Dados restaurados.");
  }
});

function render(){ document.getElementById("content").innerHTML = views[currentView](); }

const views = {
dashboard: () => {
  const active=db.projects.filter(p=>p.status.toLowerCase().includes("ativo") || p.status.toLowerCase().includes("desenvol")).length;
  const pending=db.approvals.filter(a=>a.status==="Pendente").length;
  const activePeople=db.people.filter(p=>["Ativo","Ativa"].includes(p.status)).length;
  const hours=db.hours.reduce((a,h)=>a+Number(h.hours),0);
  const upcoming=[...db.meetings].sort((a,b)=>a.date.localeCompare(b.date)).slice(0,4);
  return `
    <div class="page-head"><div><h1>Visão geral</h1><p>Carteira acadêmica, extensionista e de ensino do PIXEL.</p></div>
      <div class="actions"><button class="btn primary" onclick="openProjectModal()">+ Nova iniciativa</button></div></div>
    <div class="kpis">
      <div class="kpi"><div class="kpi-label">Iniciativas ativas</div><div class="kpi-value">${active}</div><div class="kpi-note">de ${db.projects.length} registradas</div></div>
      <div class="kpi"><div class="kpi-label">Aprovações pendentes</div><div class="kpi-value">${pending}</div><div class="kpi-note">aguardando análise</div></div>
      <div class="kpi"><div class="kpi-label">Pessoas</div><div class="kpi-value">${db.people.length}</div><div class="kpi-note">${activePeople} integrantes ativos</div></div>
      <div class="kpi"><div class="kpi-label">Horas registradas</div><div class="kpi-value">${hours}</div><div class="kpi-note">carga horária cadastrada</div></div>
    </div>
    <div class="grid-2">
      <section class="card"><h2>Iniciativas</h2>
        <div class="table-wrap"><table><thead><tr><th>Título</th><th>Tipo</th><th>Status</th><th>Progresso</th></tr></thead><tbody>
        ${db.projects.slice(0,7).map(p=>`<tr class="clickable" onclick="openProjectDetails(${p.id})"><td><strong>${esc(p.title)}</strong></td><td>${esc(p.type)}</td><td>${badge(p.status)}</td><td>${p.progress}%</td></tr>`).join("")}
        </tbody></table></div>
      </section>
      <section class="card"><h2>Próximas reuniões</h2><div class="list">
        ${upcoming.map(m=>`<div class="list-item"><strong>${esc(m.title)}</strong><div class="muted">${fmtDate(m.date)} · ${m.start}–${m.end} · ${esc(m.location)}</div></div>`).join("") || `<div class="empty">Nenhuma reunião cadastrada.</div>`}
      </div></section>
    </div>
    <div class="grid-2" style="margin-top:20px">
      <section class="card"><h2>Projetos por modalidade</h2>${typeBars()}</section>
      <section class="card"><h2>Engajamento nas reuniões</h2>${engagementBars()}</section>
    </div>`;
},
projects: () => `
  <div class="page-head"><div><h1>Iniciativas</h1><p>Projetos ativos, concluídos e histórico do PIXEL.</p></div>
  <button class="btn primary" onclick="openProjectModal()">+ Nova iniciativa</button></div>
  <section class="card">
    <div class="toolbar"><input id="projectSearch" class="search" placeholder="Buscar por título, tipo ou orientador..." oninput="filterProjects()" />
      <select id="projectStatus" onchange="filterProjects()"><option value="">Todos os status</option><option>Ativo</option><option>Em desenvolvimento</option><option>Concluído</option><option>Não informado</option></select>
      <select id="projectType" onchange="filterProjects()"><option value="">Todos os tipos</option><option>Projeto de extensão</option><option>Iniciação científica</option><option>Projeto final / TCC</option><option>Projeto / iniciativa</option></select>
    </div>
    <div id="projectTable">${projectTable(db.projects)}</div>
  </section>`,
people: () => `
  <div class="page-head"><div><h1>Pessoas</h1><p>Alunos cadastrados, interessados e histórico de participação.</p></div>
  <button class="btn primary" onclick="openPersonModal()">+ Nova pessoa</button></div>
  <section class="card">
    <div class="toolbar"><input id="peopleSearch" class="search" placeholder="Buscar nome, curso ou interesse..." oninput="filterPeople()"/>
      <select id="peopleStatus" onchange="filterPeople()"><option value="">Todos</option><option>Ativa</option><option>Ativo</option><option>Interessada</option><option>Interessado</option></select></div>
    <div id="peopleTable">${peopleTable(db.people)}</div>
  </section>`,
calendar: () => calendarView(),
hours: () => `
  <div class="page-head"><div><h1>Carga horária</h1><p>Registro de atividades por pessoa e projeto.</p></div>
  <button class="btn primary" onclick="openHourModal()">+ Registrar horas</button></div>
  <div class="kpis"><div class="kpi"><div class="kpi-label">Total de horas</div><div class="kpi-value">${db.hours.reduce((a,h)=>a+Number(h.hours),0)}</div><div class="kpi-note">registros cadastrados</div></div>
  <div class="kpi"><div class="kpi-label">Pessoas com registros</div><div class="kpi-value">${new Set(db.hours.map(h=>h.personId)).size}</div></div>
  <div class="kpi"><div class="kpi-label">Projetos envolvidos</div><div class="kpi-value">${new Set(db.hours.map(h=>h.projectId)).size}</div></div>
  <div class="kpi"><div class="kpi-label">Média por registro</div><div class="kpi-value">${db.hours.length ? Math.round(db.hours.reduce((a,h)=>a+Number(h.hours),0)/db.hours.length) : 0}</div><div class="kpi-note">horas</div></div></div>
  <section class="card"><div class="table-wrap"><table><thead><tr><th>Data</th><th>Pessoa</th><th>Projeto</th><th>Atividade</th><th>Horas</th><th></th></tr></thead><tbody>
  ${db.hours.map(h=>`<tr><td>${fmtDate(h.date)}</td><td>${esc(personName(h.personId))}</td><td>${esc(projectName(h.projectId))}</td><td>${esc(h.activity)}</td><td><strong>${h.hours}h</strong></td><td><button class="btn small danger" onclick="deleteItem('hours',${h.id})">Excluir</button></td></tr>`).join("") || `<tr><td colspan="6" class="empty">Nenhum registro.</td></tr>`}
  </tbody></table></div></section>`,
approvals: () => `
  <div class="page-head"><div><h1>Aprovações</h1><p>Solicitações aguardando análise da coordenação.</p></div></div>
  <section class="card">${db.approvals.length ? db.approvals.map(a=>`
    <div class="list-item" style="margin-bottom:10px"><div style="display:flex;justify-content:space-between;gap:15px"><div><strong>${esc(a.title)}</strong><div class="muted">${esc(a.type)} · solicitante: ${esc(a.requester)} · ${fmtDate(a.date)}</div></div>${badge(a.status)}</div>
    <p>${esc(a.description)}</p>${a.status==="Pendente" ? `<div class="actions"><button class="btn primary small" onclick="approval(${a.id},'Aprovada')">Aprovar</button><button class="btn small danger" onclick="approval(${a.id},'Ajuste solicitado')">Solicitar ajuste</button></div>` : ""}</div>`).join("") : `<div class="empty">Nenhuma solicitação.</div>`}</section>`,
reports: () => `
  <div class="page-head"><div><h1>Relatórios</h1><p>Indicadores consolidados do Grupo PIXEL.</p></div></div>
  <div class="grid-2">
    <section class="card"><h2>Projetos por modalidade</h2>${typeBars()}</section>
    <section class="card"><h2>Status dos projetos</h2>${statusBars()}</section>
  </div>
  <div class="grid-2" style="margin-top:20px">
    <section class="card"><h2>Participação por pessoa</h2>${engagementBars()}</section>
    <section class="card"><h2>Resumo</h2><div class="two-col-list">
      <div class="stat-mini"><span class="muted">Projetos</span><strong>${db.projects.length}</strong></div>
      <div class="stat-mini"><span class="muted">Pessoas</span><strong>${db.people.length}</strong></div>
      <div class="stat-mini"><span class="muted">Reuniões</span><strong>${db.meetings.length}</strong></div>
      <div class="stat-mini"><span class="muted">Horas</span><strong>${db.hours.reduce((a,h)=>a+Number(h.hours),0)}h</strong></div>
    </div></section>
  </div>`,
settings: () => `
  <div class="page-head"><div><h1>Configurações</h1><p>Preferências do PIXEL Hub e dados locais.</p></div></div>
  <section class="card">
    <div class="notice"><strong>Modo demonstração:</strong> este primeiro protótipo salva os dados no navegador usando localStorage. Isso permite publicar no GitHub Pages sem banco de dados. Na próxima etapa podemos conectar o Supabase para uso compartilhado entre os integrantes.</div>
    <h2>Informações do grupo</h2>
    <div class="form-grid">
      <div class="field"><label>Nome</label><input value="Grupo PIXEL" /></div>
      <div class="field"><label>Instituição</label><input value="CEFET/RJ" /></div>
      <div class="field full"><label>Descrição</label><textarea>Grupo de universitários dedicado ao desenvolvimento e gestão de projetos de jogos, incluindo extensão, iniciação científica e TCC.</textarea></div>
    </div>
    <button class="btn primary" onclick="showToast('Configurações salvas apenas nesta demonstração.')">Salvar configurações</button>
  </section>`
};

function projectTable(list){
 return `<div class="table-wrap"><table><thead><tr><th>Título</th><th>Tipo</th><th>Período</th><th>Responsável</th><th>Status</th><th>Progresso</th><th></th></tr></thead><tbody>
 ${list.map(p=>`<tr class="clickable"><td onclick="openProjectDetails(${p.id})"><strong>${esc(p.title)}</strong></td><td>${esc(p.type)}</td><td>${fmtDate(p.start)} — ${fmtDate(p.end)}</td><td>${esc(p.advisor)}</td><td>${badge(p.status)}</td><td>${p.progress}%</td><td><button class="btn small danger" onclick="deleteItem('projects',${p.id})">Excluir</button></td></tr>`).join("") || `<tr><td colspan="7" class="empty">Nenhuma iniciativa encontrada.</td></tr>`}
 </tbody></table></div>`;
}
function peopleTable(list){
 return `<div class="table-wrap"><table><thead><tr><th>Nome</th><th>Curso</th><th>Período</th><th>Interesse</th><th>Projetos</th><th>Status</th><th></th></tr></thead><tbody>
 ${list.map(p=>`<tr class="clickable"><td onclick="openPersonDetails(${p.id})"><strong>${esc(p.name)}</strong><div class="muted">${esc(p.email)}</div></td><td>${esc(p.course)}</td><td>${p.period}º</td><td>${esc(p.interest)}</td><td>${p.projects?.length||0}</td><td>${badge(p.status)}</td><td><button class="btn small danger" onclick="deleteItem('people',${p.id})">Excluir</button></td></tr>`).join("") || `<tr><td colspan="7" class="empty">Nenhuma pessoa encontrada.</td></tr>`}
 </tbody></table></div>`;
}
function typeBars(){
 const types={}; db.projects.forEach(p=>types[p.type]=(types[p.type]||0)+1); const max=Math.max(...Object.values(types),1);
 return Object.entries(types).map(([k,v])=>`<div class="bar-row"><div class="bar-label"><span>${esc(k)}</span><span>${v}</span></div><div class="bar"><span style="width:${v/max*100}%"></span></div></div>`).join("");
}
function statusBars(){
 const st={}; db.projects.forEach(p=>st[p.status]=(st[p.status]||0)+1); const max=Math.max(...Object.values(st),1);
 return Object.entries(st).map(([k,v])=>`<div class="bar-row"><div class="bar-label"><span>${esc(k)}</span><span>${v}</span></div><div class="bar"><span style="width:${v/max*100}%"></span></div></div>`).join("");
}
function engagementBars(){
 if(!db.meetings.length) return `<div class="empty">Cadastre reuniões para visualizar o engajamento.</div>`;
 const total=db.meetings.length;
 return db.people.filter(p=>p.status==="Ativo"||p.status==="Ativa").slice(0,8).map(p=>{
   const present=db.meetings.filter(m=>(m.present||[]).includes(p.id)).length;
   const pct=Math.round(present/total*100);
   return `<div class="bar-row"><div class="bar-label"><span>${esc(p.name)}</span><span>${pct}%</span></div><div class="bar"><span style="width:${pct}%"></span></div></div>`;
 }).join("") || `<div class="empty">Nenhum integrante ativo.</div>`;
}

function filterProjects(){
 const q=(document.getElementById("projectSearch")?.value||"").toLowerCase();
 const st=document.getElementById("projectStatus")?.value||"", ty=document.getElementById("projectType")?.value||"";
 const list=db.projects.filter(p=>(!q || `${p.title} ${p.type} ${p.advisor}`.toLowerCase().includes(q))&&(!st||p.status===st)&&(!ty||p.type===ty));
 document.getElementById("projectTable").innerHTML=projectTable(list);
}
function filterPeople(){
 const q=(document.getElementById("peopleSearch")?.value||"").toLowerCase(), st=document.getElementById("peopleStatus")?.value||"";
 const list=db.people.filter(p=>(!q||`${p.name} ${p.course} ${p.interest}`.toLowerCase().includes(q))&&(!st||p.status===st));
 document.getElementById("peopleTable").innerHTML=peopleTable(list);
}

function calendarView(){
 const base=new Date(2026,9,1), y=base.getFullYear(), m=base.getMonth(), first=new Date(y,m,1).getDay();
 const days=new Date(y,m+1,0).getDate(), prev=new Date(y,m,0).getDate();
 let cells="";
 const names=["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
 names.forEach(n=>cells+=`<div class="cal-head">${n}</div>`);
 for(let i=0;i<42;i++){
   const d=i-first+1; let num=d, cls="";
   if(d<1){num=prev+d;cls="muted-day"} else if(d>days){num=d-days;cls="muted-day"}
   const date = d>=1&&d<=days ? `2026-10-${String(d).padStart(2,"0")}` : "";
   const events=db.events.filter(e=>e.date===date);
   cells+=`<div class="cal-day ${cls}"><div class="day-number">${num}</div>${events.map(e=>`<div class="event ${e.color||""}">${esc(e.title)}</div>`).join("")}</div>`;
 }
 return `<div class="page-head"><div><h1>Calendário</h1><p>Reuniões, prazos, eventos e calendário acadêmico do PIXEL.</p></div><button class="btn primary" onclick="openEventModal()">+ Novo evento</button></div>
 <section class="card"><div class="calendar">${cells}</div></section>
 <section class="card" style="margin-top:20px"><h2>Próximos eventos</h2>${[...db.events].sort((a,b)=>a.date.localeCompare(b.date)).map(e=>`<div class="list-item" style="margin-bottom:8px"><strong>${esc(e.title)}</strong><div class="muted">${fmtDate(e.date)} · ${esc(e.type)}</div></div>`).join("")}</section>`;
}

function modal(title, body){
 document.getElementById("modalRoot").innerHTML=`<div class="modal-backdrop" onclick="if(event.target===this)closeModal()"><div class="modal"><div class="modal-head"><h2>${title}</h2><button class="close" onclick="closeModal()">×</button></div><div class="modal-body">${body}</div></div></div>`;
}
function closeModal(){document.getElementById("modalRoot").innerHTML="";}

function openProjectModal(){
 modal("Nova iniciativa",`<form onsubmit="saveProject(event)"><div class="form-grid">
 <div class="field full"><label>Título *</label><input name="title" required></div>
 <div class="field"><label>Tipo</label><select name="type"><option>Projeto de extensão</option><option>Iniciação científica</option><option>Projeto final / TCC</option><option>Projeto / iniciativa</option></select></div>
 <div class="field"><label>Status</label><select name="status"><option>Ativo</option><option>Em desenvolvimento</option><option>Concluído</option><option>Não informado</option></select></div>
 <div class="field"><label>Data de início</label><input type="date" name="start"></div><div class="field"><label>Previsão de término</label><input type="date" name="end"></div>
 <div class="field full"><label>Orientador / responsável</label><input name="advisor"></div>
 <div class="field full"><label>Descrição</label><textarea name="description"></textarea></div>
 <div class="field full"><label>Objetivo</label><textarea name="goal"></textarea></div>
 </div><div class="modal-actions"><button type="button" class="btn" onclick="closeModal()">Cancelar</button><button class="btn primary">Cadastrar iniciativa</button></div></form>`);
}
function saveProject(e){
 e.preventDefault(); const f=new FormData(e.target);
 db.projects.unshift({id:nextId(db.projects),title:f.get("title"),type:f.get("type"),status:f.get("status"),start:f.get("start"),end:f.get("end"),advisor:f.get("advisor"),description:f.get("description"),goal:f.get("goal"),members:[],progress:0});
 saveData(); closeModal(); render(); showToast("Iniciativa cadastrada.");
}
function openPersonModal(){
 modal("Nova pessoa",`<form onsubmit="savePerson(event)"><div class="form-grid">
 <div class="field full"><label>Nome completo *</label><input name="name" required></div>
 <div class="field"><label>Curso</label><input name="course"></div><div class="field"><label>Período</label><input type="number" name="period" min="1" max="20"></div>
 <div class="field"><label>E-mail</label><input type="email" name="email"></div><div class="field"><label>Status</label><select name="status"><option>Ativa</option><option>Ativo</option><option>Interessada</option><option>Interessado</option></select></div>
 <div class="field full"><label>Áreas de interesse / habilidades</label><input name="interest"></div>
 </div><div class="modal-actions"><button type="button" class="btn" onclick="closeModal()">Cancelar</button><button class="btn primary">Cadastrar pessoa</button></div></form>`);
}
function savePerson(e){
 e.preventDefault(); const f=new FormData(e.target);
 db.people.unshift({id:nextId(db.people),name:f.get("name"),course:f.get("course"),period:Number(f.get("period")||0),email:f.get("email"),status:f.get("status"),interest:f.get("interest"),projects:[]});
 saveData(); closeModal(); render(); showToast("Pessoa cadastrada.");
}
function openHourModal(){
 modal("Registrar carga horária",`<form onsubmit="saveHour(event)"><div class="form-grid">
 <div class="field"><label>Pessoa</label><select name="personId">${db.people.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join("")}</select></div>
 <div class="field"><label>Projeto</label><select name="projectId">${db.projects.map(p=>`<option value="${p.id}">${esc(p.title)}</option>`).join("")}</select></div>
 <div class="field"><label>Data</label><input type="date" name="date" required></div><div class="field"><label>Horas</label><input type="number" name="hours" min="0.5" step="0.5" required></div>
 <div class="field full"><label>Atividade</label><input name="activity" required></div>
 </div><div class="modal-actions"><button type="button" class="btn" onclick="closeModal()">Cancelar</button><button class="btn primary">Registrar</button></div></form>`);
}
function saveHour(e){
 e.preventDefault(); const f=new FormData(e.target); db.hours.unshift({id:nextId(db.hours),personId:Number(f.get("personId")),projectId:Number(f.get("projectId")),activity:f.get("activity"),date:f.get("date"),hours:Number(f.get("hours"))});
 saveData();closeModal();render();showToast("Carga horária registrada.");
}
function openEventModal(){
 modal("Novo evento",`<form onsubmit="saveEvent(event)"><div class="form-grid">
 <div class="field full"><label>Título *</label><input name="title" required></div><div class="field"><label>Data</label><input type="date" name="date" required></div>
 <div class="field"><label>Tipo</label><select name="type"><option>Reunião</option><option>Projeto</option><option>Evento</option><option>Prazo</option><option>Calendário acadêmico</option></select></div>
 <div class="field"><label>Cor</label><select name="color"><option value="purple">Roxo</option><option value="blue">Azul</option><option value="green">Verde</option><option value="yellow">Amarelo</option></select></div>
 </div><div class="modal-actions"><button type="button" class="btn" onclick="closeModal()">Cancelar</button><button class="btn primary">Cadastrar evento</button></div></form>`);
}
function saveEvent(e){e.preventDefault();const f=new FormData(e.target);db.events.push({id:nextId(db.events),title:f.get("title"),date:f.get("date"),type:f.get("type"),color:f.get("color")});saveData();closeModal();render();showToast("Evento cadastrado.");}
function openProjectDetails(id){
 const p=db.projects.find(x=>x.id===id); if(!p)return;
 const members=db.people.filter(x=>(p.members||[]).includes(x.id));
 const tasks=db.tasks.filter(t=>t.projectId===id);
 modal(esc(p.title),`<div class="notice">${badge(p.status)} &nbsp; ${esc(p.type)} · ${fmtDate(p.start)} — ${fmtDate(p.end)}</div>
 <div class="two-col-list"><div class="stat-mini"><span class="muted">Orientador</span><strong style="font-size:17px">${esc(p.advisor)}</strong></div><div class="stat-mini"><span class="muted">Progresso</span><strong>${p.progress}%</strong></div></div>
 <h3 style="margin-top:20px">Descrição</h3><p class="muted">${esc(p.description||"Sem descrição.")}</p>
 <h3>Objetivo</h3><p class="muted">${esc(p.goal||"Não informado.")}</p>
 <h3>Equipe</h3><div class="list">${members.map(m=>`<div class="list-item"><strong>${esc(m.name)}</strong><span class="muted">${esc(m.course)} · ${esc(m.interest)}</span></div>`).join("")||`<div class="empty">Nenhum membro vinculado.</div>`}</div>
 <h3 style="margin-top:18px">Tarefas</h3><div class="list">${tasks.map(t=>`<div class="list-item"><strong>${esc(t.title)}</strong><div class="muted">${esc(personName(t.personId))} · ${fmtDate(t.due)} · ${badge(t.status)}</div></div>`).join("")||`<div class="empty">Nenhuma tarefa.</div>`}</div>`);
}
function openPersonDetails(id){
 const p=db.people.find(x=>x.id===id);if(!p)return;
 const projects=db.projects.filter(x=>(p.projects||[]).includes(x.id));
 const pres=db.meetings.filter(m=>(m.present||[]).includes(id)).length, total=db.meetings.length;
 const pct=total?Math.round(pres/total*100):0;
 modal(esc(p.name),`<div class="notice">${badge(p.status)} &nbsp; ${esc(p.course)} · ${p.period}º período</div>
 <div class="two-col-list"><div class="stat-mini"><span class="muted">E-mail</span><strong style="font-size:15px">${esc(p.email)}</strong></div><div class="stat-mini"><span class="muted">Engajamento</span><strong>${pct}%</strong></div></div>
 <h3 style="margin-top:20px">Interesses e habilidades</h3><p class="muted">${esc(p.interest||"Não informado.")}</p>
 <h3>Projetos</h3><div class="list">${projects.map(x=>`<div class="list-item"><strong>${esc(x.title)}</strong><span class="muted">${esc(x.type)} · ${esc(x.status)}</span></div>`).join("")||`<div class="empty">Nenhum projeto vinculado.</div>`}</div>`);
}
function approval(id,status){const a=db.approvals.find(x=>x.id===id);if(a){a.status=status;saveData();render();showToast(`Solicitação: ${status.toLowerCase()}.`);}}
function deleteItem(collection,id){
 if(!confirm("Excluir este registro?"))return;
 db[collection]=db[collection].filter(x=>x.id!==id);saveData();render();showToast("Registro excluído.");
}

render();
