# PIXEL Hub

Sistema web de gestão acadêmica e de projetos para o Grupo PIXEL.

## O que já está funcionando

- Dashboard com indicadores automáticos
- Cadastro de iniciativas/projetos
- Histórico de iniciativas
- Cadastro de pessoas e interessados
- Detalhes de pessoas e projetos
- Calendário de reuniões, prazos e eventos
- Registro de carga horária
- Fluxo simples de aprovações
- Relatórios e indicadores
- Dados persistidos no navegador com `localStorage`
- Interface responsiva
- Sem dependências externas: pode ser publicado diretamente no GitHub Pages

## Executar localmente

Basta abrir `index.html` no navegador.

Para desenvolvimento local, também pode usar qualquer servidor estático, por exemplo:

```bash
python -m http.server 8000
```

Depois acesse `http://localhost:8000`.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub, por exemplo `pixel-hub`.
2. Envie `index.html`, `styles.css`, `app.js` e `README.md`.
3. No repositório, abra **Settings > Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde a publicação.

O endereço ficará semelhante a:

`https://SEU-USUARIO.github.io/pixel-hub/`

## Importante sobre os dados

Esta versão é um MVP sem backend. Os dados ficam salvos no navegador de cada pessoa.

Isso é ótimo para prototipar, mas não para o uso real do grupo, porque Ana e João teriam bancos diferentes.

### Próxima evolução recomendada

Conectar o projeto a:

- Supabase PostgreSQL
- Supabase Auth
- Row Level Security
- Storage para documentos
- usuários com perfis Administrador / Coordenador / Líder / Aluno
- banco compartilhado entre todos os integrantes

A interface atual foi preparada para essa evolução.
